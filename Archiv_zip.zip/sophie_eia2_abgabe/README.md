# ENDABGABE EIA 2, WiSe 2020 / 2021

### "Firework"

Name: Sophie Joy Campbell
<br> Matrikelnummer: 263530
<br> Datum: 15.02.2021

Hiermit versichere ich, dass der abgegebene Code selbst erstellt und unter Zusammenarbeit mit meiner Kommilitionin Anna Wagner (wie auch schon die Wochenaufgaben) entstanden ist. 